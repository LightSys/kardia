import re
from datetime import datetime


class APIObject():

    def __init__(self) -> None:
        self.s_created_by = "api"
        self.s_modified_by = self.s_created_by
        self.s_date_created = self.getKardiaDatetime()
        self.s_date_modified = self.s_date_created
        setattr(self, "__cx_osml_control", None)
        self.required_attrs = []

    def checkValid(self) -> None:
        msg = "Invalid Transaction: {} is required."
        for attr in self.required_attrs:
            if not getattr(self, attr):
                raise Exception(msg.format(attr))

    def serialize(self) -> dict:
        self.checkValid()
        d = self.__dict__
        return {key: d[key] for key in d if re.search(r"^\w{1}_.*", key)}

    def getKardiaDatetime(self, date: datetime = datetime.today()) -> dict:
        if not date:
            date = datetime.today()
        return {
            "year": date.year,
            "month": date.month,
            "day": date.day,
            "hour": date.hour,
            "minute": date.minute,
            "second": date.second
        }

    def getKardiaMoney(self, amount: str = "0.00"):
        if "." not in amount:
            amount += ".00"
        money = amount.split(".")
        return {
            "wholepart": int(money[0]),
            "fractionpart": int(money[1]) * 100
        }
