from .api_object import APIObject
from datetime import datetime
from enum import Enum

class ReportObject(APIObject):
    pass


class SchedStatusTypes(Enum):
        NOT_SENT = "N"
        SENT = "S"
        TEMPORARY_ERROR = "T"
        INVALID_EMAIL_ERROR = "I"
        FAILURE_OTHER_ERROR = "F"


class SchedReportStatus(ReportObject):

    def __init__(self, sent_status: SchedStatusTypes, sent_error: str, sent_date: datetime, generated_report_path: str):
        self.sent_status = sent_status.value
        self.sent_error = sent_error
        self.sent_date = self.getKardiaDatetime(sent_date)
        self.generated_report_path = generated_report_path

    def serialize(self) -> dict:
        return self.__dict__


class SchedReportBatchStatus(ReportObject):

    def __init__(self, sent_status: SchedStatusTypes = None, sent_by: str = None):
        if sent_status is not None:
            self.sent_status = sent_status.value
        if sent_by is not None:
            self.sent_by = sent_by

    def serialize(self) -> dict:
        return self.__dict__