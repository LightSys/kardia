from .modules import disbursements, gl, crm, crm_config, partner, donor, report


class ResTypes():
    COLLECTION = "collection"
    ELEMENT = "element"
    BOTH = "both"


class ResFormats():
    ATTRS = "attrs"
    AUTO = "auto"
    CONTENT = "content"
    BOTH = "both"


class ResAttrs():
    BASIC = "basic"
    FULL = "full"
    NONE = "none"


class ResLevels():
    ONE = "1"
    TWO = "2"
    THREE = "3"
    FOUR = "4"
    FIVE = "5"


class Kardia:

    def __init__(self, kardia_url, user, pw):
        self.kardia_config = {
            "kardia_url": kardia_url,
            "user": user,
            "pw": pw
        }
        self._gl = None
        self._crm = None
        self._partner = None
        self._crm_config = None
        self._donor = None
        self._disb = None
        self._report = None
        self._sys_config = None

    @property
    def gl(self):
        if not self._gl:
            self._gl = gl.GL(**self.kardia_config)
        return self._gl

    @property
    def crm(self):
        if not self._crm:
            self._crm = crm.CRM(**self.kardia_config)
        return self._crm

    @property
    def crm_config(self):
        if not self._crm_config:
            self._crm_config = crm_config.CRM_Config(**self.kardia_config)
        return self._crm_config

    @property
    def partner(self) -> partner.Partner:
        if not self._partner:
            self._partner = partner.Partner(**self.kardia_config)
        return self._partner

    @property
    def donor(self) -> donor.Donor:
        if not self._partner:
            self._donor = donor.Donor(**self.kardia_config)
        return self._donor

    @property
    def disb(self) -> disbursements.Disbursements:
        if not self._disb:
            self._disb = disbursements.Disbursements(**self.kardia_config)
        return self._disb

    @property
    def report(self) -> report.Report:
        if not self._report:
            self._report = report.Report(**self.kardia_config)
        return self._report

    # @property
    # def sys_config(self) -> sys_config.SysConfig:
    #     if not self._sys_config:
    #         self._sys_config = sys_config.SysConfig(**self.kardia_config)
    #     return self._sys_config
