from requests.models import Response
from .api_module import APIModule
from enum import Enum

# ------------------------------------ Endpoints ------------------------------------


class Endpoints(Enum):
    PARENT = None
    PARTNERS = "Partners"
    STAFF = "Staff"
    STAFF_LOGINS = "StaffLogins"
    CONTACT_TYPES = "ContactTypes"
    TEST = "Test"
    NEXT_PARTNER_KEY = "NextPartnerKey"


class PartnerEndpoints(Enum):
    PARENT = Endpoints.PARTNERS
    ADDRESSES = "Addresses"
    CONTACT_INFO = "ContactInfo"
    PREFERRED_EMAIL = "PreferredEmail"
    SUBSCRIPTIONS = "Subscriptions"

# ------------------------------------ Module ------------------------------------


class Partner(APIModule):

    # ------------------------------------ Init ------------------------------------

    def __init__(self, kardia_url, user, pw):
        super().__init__(kardia_url, user, pw)
        self.module = self.__class__.__name__.lower()

    # ------------------------------------ Getters ------------------------------------

    def getPartners(self) -> Response:
        return self._getEndpoint(Endpoints.PARTNERS)

    def getPartner(self, partner_id: str) -> Response:
        return self._getEndpoint(Endpoints.PARTNERS, partner_id)

    def getPartnerAddresses(self, partner_id) -> Response:
        return self._getEndpoint(PartnerEndpoints.ADDRESSES, partner_id)

    def getPartnerAddress(self, partner_id, location_id) -> Response:
        address_name = "{}|{}|0".format(partner_id, location_id)
        return self._getEndpoint(PartnerEndpoints.ADDRESSES, partner_id, address_name)

    def getPartnerContactInfos(self, partner_id) -> Response:
        return self._getEndpoint(PartnerEndpoints.CONTACT_INFO, partner_id)

    def getPartnerContactInfo(self, partner_id, contact_id) -> Response:
        info_name = "{}|{}".format(partner_id, contact_id)
        return self._getEndpoint(PartnerEndpoints.CONTACT_INFO, partner_id, info_name)

    def getPartnerPreferredEmail(self, partner_id) -> Response:
        return self._getEndpoint(PartnerEndpoints.PREFERRED_EMAIL, partner_id)

    def getPartnerSubscriptions(self, partner_id) -> Response:
        return self._getEndpoint(PartnerEndpoints.SUBSCRIPTIONS, partner_id)

    def getPartnerSubscription(self, partner_id, list_id) -> Response:
        # TODO Figure out what the third number means
        list_name = "{}|{}|1".format(list_id, partner_id)
        return self._getEndpoint(PartnerEndpoints.SUBSCRIPTIONS, partner_id, list_name)

    def getStaff(self) -> Response:
        return self._getEndpoint(Endpoints.STAFF)

    def getStaffMember(self, staff_id) -> Response:
        return self._getEndpoint(Endpoints.STAFF, staff_id)

    def getStaffLogins(self) -> Response:
        return self._getEndpoint(Endpoints.STAFF_LOGINS)

    def getStaffLogin(self, username) -> Response:
        return self._getEndpoint(Endpoints.STAFF_LOGINS, username)

    def getContactTypes(self) -> Response:
        return self._getEndpoint(Endpoints.CONTACT_TYPES)

    def getContactType(self, contact_type) -> Response:
        return self._getEndpoint(Endpoints.CONTACT_TYPES, contact_type)

    def getTests(self) -> Response:
        return self._getEndpoint(Endpoints.TEST)

    def getTest(self, test) -> Response:
        return self._getEndpoint(Endpoints.TEST, test)

    def getNextPartnerKey(self) -> Response:
        return self._getEndpoint(Endpoints.NEXT_PARTNER_KEY, attrs=True)
